// popup.js - Minimal script for popup.html
// Everything is now handled in Gmail (content.js and background.js)
console.log("Recruit-AI popup loaded.");
