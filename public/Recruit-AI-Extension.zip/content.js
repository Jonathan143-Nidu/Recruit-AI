// content.js - Recruit-AI Extension v4 (Premium UI + Advanced Extraction)

// --- 1. DESIGN SYSTEM (Premium Glassmorphism) ---
const STYLE_TOKENS = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono&display=swap');
    
    .gmail-saver-btn {
        background: linear-gradient(135deg, #0b57d0 0%, #0842a0 100%);
        color: white;
        border: none;
        border-radius: 24px;
        padding: 6px 16px;
        margin-left: 15px;
        font-weight: 600;
        cursor: pointer;
        font-family: 'Inter', sans-serif;
        font-size: 13px;
        box-shadow: 0 4px 12px rgba(11, 87, 208, 0.2);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        display: inline-flex;
        align-items: center;
        gap: 8px;
        white-space: nowrap;
    }
    .gmail-saver-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 16px rgba(11, 87, 208, 0.35);
        background: linear-gradient(135deg, #0d6efd 0%, #0842a0 100%);
    }
    
    .gs-modal-backdrop {
        position: fixed;
        top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(15, 23, 42, 0.4);
        backdrop-filter: blur(8px);
        z-index: 10000;
        display: flex;
        justify-content: center;
        align-items: center;
        font-family: 'Inter', sans-serif;
    }

    .gs-card {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(20px) saturate(180%);
        border: 1px solid rgba(255, 255, 255, 0.4);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);
        border-radius: 20px;
        width: 520px;
        padding: 28px;
        color: #1e293b;
    }

    .gs-input-group { margin-bottom: 18px; }
    .gs-label { font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 6px; display: block; }
    
    .gs-input {
        width: 100%; padding: 10px 14px; border-radius: 10px; border: 1px solid #e2e8f0;
        background: white; font-size: 14px; color: #1e293b; transition: all 0.2s;
        box-sizing: border-box;
    }
    .gs-input:focus { outline: none; border-color: #0b57d0; box-shadow: 0 0 0 4px rgba(11, 87, 208, 0.1); }
    .gs-input:disabled { background: #f8fafc; color: #94a3b8; border-color: #f1f5f9; }

    .gs-terminal {
        background: #0f172a;
        border-radius: 12px;
        padding: 14px;
        height: 120px;
        overflow-y: auto;
        font-family: 'JetBrains Mono', monospace;
        font-size: 11px;
        color: #e2e8f0;
        line-height: 1.6;
        box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
    }

    .gs-pill-container {
        max-height: 100px; overflow-y: auto; gap: 8px; display: flex; flex-direction: column;
        background: #f8fafc; border-radius: 12px; padding: 10px; border: 1px solid #f1f5f9;
        margin-bottom: 18px;
    }
`;

const styleEl = document.createElement('style');
styleEl.innerHTML = STYLE_TOKENS;
document.head.appendChild(styleEl);

// --- 2. CORE LOGIC ---
let lastUrl = location.href;

function init() {
    console.log("Recruit-AI v4: Initialized");
    
    const observer = new MutationObserver(() => triggerCheck());
    observer.observe(document.body, { childList: true, subtree: true });
    
    setInterval(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            triggerCheck();
        }
    }, 1000);

    triggerCheck();
}

function triggerCheck() {
    // 1. Target the Thread Subject - Ensures ONE button per thread
    const subjectHeader = document.querySelector('h2.hP'); 
    if (!subjectHeader) return;

    const parent = subjectHeader.parentElement;
    if (parent && !parent.querySelector('.gmail-saver-btn')) {
        injectButton(parent);
    }
}

function injectButton(container) {
    const btn = document.createElement('button');
    btn.className = 'gmail-saver-btn';
    btn.innerHTML = '<span>🚀</span> Save Candidate';
    
    container.style.display = 'flex';
    container.style.alignItems = 'center';
    container.appendChild(btn);

    btn.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        btn.innerHTML = '<span>⏳</span> Scanning...';
        btn.disabled = true;

        try {
            await showModal();
        } finally {
            btn.innerHTML = '<span>🚀</span> Save Candidate';
            btn.disabled = false;
        }
    };
}

async function showModal() {
    if (document.getElementById('gs-modal')) return;

    // Get Subject
    const subjectEl = document.querySelector('h2.hP');
    const subjectText = subjectEl ? subjectEl.innerText : "New Candidate";

    // Create Backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'gs-modal';
    backdrop.className = 'gs-modal-backdrop';
    
    // Initial Scanning State
    const card = document.createElement('div');
    card.className = 'gs-card';
    card.innerHTML = `
        <div style="text-align:center; padding: 20px;">
            <div style="font-size: 20px; margin-bottom: 8px;">🔍</div>
            <div style="font-weight: 600; font-size: 15px; margin-bottom: 4px;">Analyzing Candidate Thread</div>
            <div style="font-size: 12px; color: #64748b;">Expanding all messages and picking up attachments...</div>
        </div>
    `;
    backdrop.appendChild(card);
    document.body.appendChild(backdrop);

    try {
        await expandAllThreads();
        const emailData = await extractEmailData();
        emailData.subject = subjectText;
        emailData.threadLink = window.location.href;

        chrome.runtime.sendMessage({ action: "fetchFolders" }, (response) => {
            if (!response || !response.success) {
                renderError(card, response ? response.error : "Failed to connect to backend.");
            } else {
                renderForm(card, emailData, response.folders);
            }
        });
    } catch (err) {
        renderError(card, "Extraction Error: " + err.message);
    }
}

function renderForm(card, emailData, folders) {
    let attachmentHtml = '';
    emailData.attachments.forEach((att, idx) => {
        attachmentHtml += `
            <div style="display:flex; align-items:center; gap:10px; padding: 4px 0;">
                <input type="checkbox" id="att-${idx}" checked style="accent-color: #0b57d0;">
                <label for="att-${idx}" style="font-size: 13px; color: #334155; cursor: pointer; overflow:hidden; text-overflow:ellipsis;">
                    📄 ${att.name}
                </label>
            </div>
        `;
    });

    const folderOpts = folders.map(f => `<option value="${f.name}">${f.name}</option>`).join('');

    card.innerHTML = `
        <h2 style="margin: 0 0 24px 0; font-size: 18px; font-weight: 600; color: #0f172a;">Save Candidate</h2>

        <div class="gs-input-group">
            <span class="gs-label">Candidate (Subject)</span>
            <input type="text" value="${emailData.subject}" disabled class="gs-input">
        </div>

        <div class="gs-input-group">
            <span class="gs-label">Candidate Email</span>
            <input type="text" id="gs-email" value="${emailData.senderEmail}" placeholder="candidate@email.com" class="gs-input">
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 18px;">
            <div>
                <span class="gs-label">Role Folder</span>
                <select id="gs-folder-select" class="gs-input">
                    <option value="">-- Select --</option>
                    ${folderOpts}
                </select>
            </div>
            <div>
                <span class="gs-label">New Folder</span>
                <input type="text" id="gs-new-folder" placeholder="e.g. Java Arch" class="gs-input">
            </div>
        </div>

        <span class="gs-label">Attachments</span>
        <div class="gs-pill-container">
            ${attachmentHtml || '<div style="font-size:12px; color:#94a3b8; text-align:center;">No documents found.</div>'}
        </div>

        <span class="gs-label">Activity Log</span>
        <div id="gs-log" class="gs-terminal">
            <div style="color: #64748b;">// Initializing extraction...</div>
        </div>

        <div style="display:flex; justify-content: flex-end; gap: 12px; margin-top: 24px;">
            <button id="gs-cancel" style="background:none; border:none; color:#64748b; font-weight:600; cursor:pointer; padding: 8px 16px;">Cancel</button>
            <button id="gs-save" class="gs-btn-primary" style="padding: 10px 24px;">Save to Drive</button>
        </div>
        <div id="gs-status" style="margin-top: 16px; text-align: center; font-size: 13px; font-weight: 600;"></div>
    `;

    document.getElementById('gs-cancel').onclick = () => document.getElementById('gs-modal').remove();

    document.getElementById('gs-save').onclick = async () => {
        const btn = document.getElementById('gs-save');
        const status = document.getElementById('gs-status');
        btn.disabled = true;
        btn.innerText = 'Saving...';

        const folder = document.getElementById('gs-new-folder').value.trim() || document.getElementById('gs-folder-select').value;
        const selectedAtts = [];
        emailData.attachments.forEach((att, idx) => {
            if (document.getElementById(`att-${idx}`).checked) selectedAtts.push(att);
        });

        const payload = {
            subject: emailData.subject,
            senderEmail: document.getElementById('gs-email').value || emailData.senderEmail,
            threadLink: emailData.threadLink,
            emailBody: emailData.body,
            attachments: selectedAtts,
            manualFolderName: folder,
            processedBy: document.title.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/) ? RegExp.$1 : "Unknown"
        };

        chrome.runtime.sendMessage({ action: "processEmail", payload }, (response) => {
            if (response && response.success) {
                status.style.color = response.skipped ? '#d97706' : '#10b981';
                status.innerText = response.skipped ? '⚠️ Duplicate skipped' : '✅ Candidate Saved!';
                setTimeout(() => document.getElementById('gs-modal').remove(), 2500);
            } else {
                status.style.color = '#ef4444';
                status.innerText = '❌ Failed to save candidate.';
                btn.disabled = false;
                btn.innerText = 'Save to Drive';
            }
        });
    };
}

function renderError(card, msg) {
    card.innerHTML = `
        <div style="text-align:center;">
            <div style="color:#ef4444; font-size: 24px; margin-bottom: 12px;">⚠️</div>
            <div style="font-weight:600; margin-bottom: 8px;">Something went wrong</div>
            <div style="font-size:13px; color:#64748b; margin-bottom: 20px;">${msg}</div>
            <button onclick="document.getElementById('gs-modal').remove()" class="gs-btn-primary">Dismiss</button>
        </div>
    `;
}

// --- 3. EXTRACTION UTILS ---

async function expandAllThreads() {
    const selectors = [
        '[aria-label="Expand all"]', 
        'img[alt="Expand all"]', 
        '.kQ', // "X more messages"
        '.adx'  // Individual message ellipsis
    ];
    
    for (const sel of selectors) {
        const btns = document.querySelectorAll(sel);
        btns.forEach(btn => btn.click());
    }
    
    // Wait for DOM to catch up
    await new Promise(r => setTimeout(r, 1500));
}

async function extractEmailData() {
    const bodies = document.querySelectorAll('.a3s.aiL');
    let fullBody = '';
    bodies.forEach(b => fullBody += b.innerText + '\n---\n');

    // Extract sender email from the first message
    let senderEmail = "Unknown";
    const messages = document.querySelectorAll('.adn');
    if (messages.length > 0) {
        const firstSenderEl = messages[0].querySelector('span.gD');
        if (firstSenderEl) senderEmail = firstSenderEl.getAttribute('email') || firstSenderEl.innerText;
    }

    // Grouping per message container to prevent ID collisions (e.g. two messages both having an attachment '0.1')
    const byId = new Map();
    // (messages is already declared above)

    messages.forEach((msg, msgIdx) => {
        const links = msg.querySelectorAll('a[href*="view=att"], a[href*="disp=attd"], a[href*="disp=safe"]');
        links.forEach(link => {
            const url = link.href;
            const attIdMatch = url.match(/[?&]attid=([^&]+)/);
            const attId = attIdMatch ? attIdMatch[1] : url;

            // Unique key includes message index to separate different emails in the same thread
            const uniqueKey = `${msgIdx}_${attId}`;

            if (byId.has(uniqueKey)) return;

            const name = cleanFilename(link);
            if (!name || name.toLowerCase().includes('thumbnail')) return;

            const ext = name.split('.').pop().toLowerCase();
            byId.set(uniqueKey, {
                name: name,
                url: url.replace('disp=safe', 'disp=attd').replace('disp=inline', 'disp=attd'),
                mimeType: getMime(ext)
            });
        });
    });

    return { body: fullBody, senderEmail: senderEmail, attachments: Array.from(byId.values()) };
}

function cleanFilename(el) {
    // 1. Prioritize aria-label then download
    let name = el.getAttribute('aria-label') || el.getAttribute('download') || el.innerText || '';
    
    // 2. Initial cleanup
    const prefixes = ["Preview attachment ", "Download attachment ", "Download ", "Preview ", "File attachment ", "Preview attachment: "];
    let cleaned = name.trim().split('\n')[0]; // Take only first line

    let changed = true;
    while (changed) {
        changed = false;
        for (const p of prefixes) {
            if (cleaned.toLowerCase().startsWith(p.toLowerCase())) {
                cleaned = cleaned.slice(p.length).trim();
                changed = true;
            }
        }
    }

    // 3. SMART TRUNCATION: Gmail chips repeat the name. Stop at the FIRST extension.
    const extMatch = cleaned.match(/\.(pdf|docx|doc|txt|jpg|jpeg|png|jpeg)/i);
    if (extMatch) {
        const index = cleaned.toLowerCase().indexOf(extMatch[0].toLowerCase());
        cleaned = cleaned.slice(0, index + extMatch[0].length);
    }
    
    // 4. Final cleaning
    return cleaned.replace(/^[\s\-_]+|[\s\-_]+$/g, '').trim();
}

function getMime(ext) {
    const map = {
        pdf: 'application/pdf',
        docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        doc: 'application/msword',
        png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg'
    };
    return map[ext] || 'application/octet-stream';
}

function addLog(msg, color = '#64748b') {
    const log = document.getElementById('gs-log');
    if (log) {
        const line = document.createElement('div');
        const time = new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
        line.innerHTML = `<span style="color: #475569;">[${time}]</span> <span style="color: ${color}">${msg}</span>`;
        log.appendChild(line);
        log.scrollTop = log.scrollHeight;
    }
}

// Global Message Listener for Progress Tags
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "updateProgress") {
        let color = '#94a3b8';
        if (request.msg.includes('SUCCESS')) color = '#10b981';
        if (request.msg.includes('ERROR')) color = '#ef4444';
        if (request.msg.includes('UPLOAD')) color = '#fbbf24';
        addLog(request.msg, color);
    }
});

init();