// background.js - API Proxy and Config

// Configuration (Hardcoded for "Test Phase" as requested)
const WEB_APP_URL = "http://localhost:3000";
const ACCESS_CODE = "secret123";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fetchFolders") {
        handleFetchFolders(sendResponse);
        return true; // Async response
    }

    if (request.action === "processEmail") {
        handleProcessEmail(request.payload, sendResponse);
        return true; // Async response
    }
    if (request.action === "downloadAttachment") {
        handleDownloadAttachment(request.url, sendResponse);
        return true;
    }
});

async function handleDownloadAttachment(url, sendResponse) {
    try {
        const response = await fetch(url);
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64 = reader.result.split(',')[1];
            sendResponse({ success: true, base64 });
        };
        reader.readAsDataURL(blob);
    } catch (error) {
        console.error("Download Attachment Failed:", error);
        sendResponse({ success: false, error: error.message });
    }
}

async function handleFetchFolders(sendResponse) {
    try {
        const response = await fetch(`${WEB_APP_URL}/api/folders`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`Server Error: ${response.status}`);
        }

        const data = await response.json();
        sendResponse({ success: true, folders: data.folders });
    } catch (error) {
        console.error("Fetch Folders Failed:", error);
        sendResponse({ success: false, error: error.message });
    }
}

async function handleProcessEmail(payload, sendResponse) {
    // 1. Respond quickly to the Content Script to let it close the modal
    sendResponse({ success: true, message: "Processing started in background." });

    try {
        const finalPayload = {
            ...payload,
            accessCode: ACCESS_CODE
        };

        const response = await fetch(`${WEB_APP_URL}/api/process`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(finalPayload)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || `Server Error: ${response.status}`);
        }

        // 2. Show Success Notification
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon128.png',
            title: 'Candidate Saved!',
            message: `Successfully saved ${data.candidate?.Name || 'Candidate'} to ${payload.manualFolderName || 'Drive'}.`,
            priority: 2
        });

    } catch (error) {
        console.error("Process Email Failed:", error);

        // 3. Show Error Notification
        chrome.notifications.create({
            type: 'basic',
            iconUrl: 'icon128.png',
            title: 'Extraction Failed',
            message: `Error: ${error.message}`,
            priority: 2
        });
    }
}
