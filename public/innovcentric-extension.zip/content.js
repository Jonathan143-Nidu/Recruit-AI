// content.js - In-Page UI & Extraction Logic

// --- 1. DOMAIN CHECK ---
function checkDomain() {
    const title = document.title;
    console.log("Checking domain for title:", title);
    // TEMPORARY: Allow all for debugging if needed, but keeping logic
    // if (!title.includes('@innovcentric.com')) {
    //     console.warn("Gmail Candidate Saver: Domain restriction active. Not @innovcentric.com. Extension PAUSED.");
    //     return false; 
    // }
    return true; // Bypass for debugging
}

// --- 2. UI INJECTION ---
let observer = null;

function init() {
    console.log("Gmail Saver: Content Script Loaded");
    if (!checkDomain()) return;

    // Observer to detect when an email is opened
    observer = new MutationObserver((mutations) => {
        // Broaden selectors for Sender Name
        // .gD = standard sender name
        // .qu = quote/reply sender
        // span[email] = sometimes used
        // h3 span = sometimes in headers
        const selectors = ['.gD', '.qu', 'span[email]', 'h3 span'];
        let senderElement = null;

        for (const sel of selectors) {
            const found = document.querySelector(sel);
            if (found && found.innerText.length > 0) {
                senderElement = found;
                break;
            }
        }

        if (senderElement && !document.getElementById('gmail-saver-btn')) {
            // ONLY inject if we are looking at an actual email thread (search for h2.hP subject)
            const isThread = document.querySelector('h2.hP');
            if (isThread) {
                console.log("Gmail Saver: Found sender element in thread", senderElement);
                injectButton(senderElement);
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
}

function injectButton(senderElement) {
    // Check if we already injected into this specific element (or its parent wrapper)
    if (senderElement.dataset.saverInjected === 'true') return;

    // Also check if a button already exists right next to it
    if (senderElement.parentElement && senderElement.parentElement.querySelector('.gmail-saver-btn')) return;
    if (senderElement.nextElementSibling && senderElement.nextElementSibling.classList.contains('gmail-saver-btn')) return;

    interaction_target = senderElement; // Save for reference
    senderElement.dataset.saverInjected = 'true';

    console.log("Gmail Saver: Injecting Button for", senderElement.innerText);
    const btn = document.createElement('button');
    btn.className = 'gmail-saver-btn';
    btn.innerText = '💾 Save';
    btn.style.cssText = `
        background-color: #0b57d0;
        color: white;
        border: none;
        border-radius: 18px;
        padding: 4px 12px;
        margin-left: 8px;
        font-weight: 500;
        cursor: pointer;
        font-family: 'Google Sans',Roboto,RobotoDraft,Helvetica,Arial,sans-serif;
        font-size: 12px;
        vertical-align: middle;
        z-index: 900;
        box-shadow: 0 1px 2px rgba(0,0,0,0.2);
        display: inline-block;
    `;

    // Safety check for parent
    if (senderElement.parentElement) {
        senderElement.parentElement.appendChild(btn);
    } else {
        // Fallback: insert after
        senderElement.parentNode.insertBefore(btn, senderElement.nextSibling);
    }

    btn.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        await showModal(senderElement);
    };
}

// --- 3. MODAL UI ---
async function showModal(senderElement) {
    if (document.getElementById('gmail-saver-modal')) return;

    // Extract Sender Email & Thread Link
    let senderEmail = 'Unknown';
    if (senderElement) {
        senderEmail = senderElement.getAttribute('email') || senderElement.title || senderElement.innerText;
        // Basic cleanup if it's "Name <email>"
        const match = senderEmail.match(/<([^>]+)>/);
        if (match) senderEmail = match[1];
    }
    const threadLink = window.location.href;

    // Create Modal Backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'gmail-saver-modal';
    backdrop.style.cssText = `
        position: fixed;
        top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 10000;
        display: flex;
        justify-content: center;
        align-items: center;
    `;

    // Create Modal Content
    const modal = document.createElement('div');
    modal.style.cssText = `
        background: white;
        padding: 24px;
        border-radius: 8px;
        width: 450px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        font-family: Roboto, sans-serif;
    `;

    // Status / Loading
    modal.innerHTML = `<h3>Loading data...</h3>`;
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    // 1. Scan Data
    await expandAllThreads();
    const emailData = await extractEmailData();

    // Add missing fields
    emailData.senderEmail = senderEmail;
    emailData.threadLink = threadLink;

    // 2. Fetch Folders (via Background)
    chrome.runtime.sendMessage({ action: "fetchFolders" }, (response) => {
        if (!response || !response.success) {
            renderError(modal, response ? response.error : "Failed to fetch folders.");
        } else {
            renderForm(modal, emailData, response.folders);
        }
    });
}

function renderForm(modal, emailData, folders) {
    let attachmentHtml = '';
    if (emailData.attachments.length === 0) {
        attachmentHtml = '<p style="color:red; font-size:12px;">No attachments found.</p>';
    } else {
        emailData.attachments.forEach((att, idx) => {
            attachmentHtml += `
                <div style="display:flex; align-items:center; margin-bottom:4px;">
                    <input type="checkbox" id="att-${idx}" checked style="margin-right:8px;">
                    <label for="att-${idx}" style="font-size:13px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:300px;" title="${att.name}">
                        ${att.name} ${att.error ? '<span style="color:red">(' + att.error + ')</span>' : ''}
                    </label>
                </div>
            `;
        });
    }

    const folderOptions = folders.map(f => `<option value="${f.name}">${f.name}</option>`).join('');

    modal.innerHTML = `
        <div style="margin-bottom:16px;">
            <label style="display:block; font-size:12px; margin-bottom:4px; color:#5f6368;">Sender Email</label>
            <input type="text" value="${emailData.senderEmail}" disabled style="width:100%; padding:8px; background:#f1f3f4; border:none; border-radius:4px; color:#666;">
        </div>

        <div style="margin-bottom:16px;">
            <label style="display:block; font-size:12px; margin-bottom:4px; color:#5f6368;">Candidate Name (Subject)</label>
            <input type="text" value="${emailData.subject}" disabled style="width:100%; padding:8px; background:#f1f3f4; border:none; border-radius:4px;">
        </div>
        
        <div style="margin-bottom:16px;">
            <label style="display:block; font-size:12px; margin-bottom:4px; color:#5f6368;">Select Role Folder</label>
            <select id="folder-select" style="width:100%; padding:8px; border:1px solid #dadce0; border-radius:4px;">
                <option value="">-- Select Existing Folder --</option>
                ${folderOptions}
            </select>
        </div>
        
        <div style="margin-bottom:16px;">
            <label style="display:block; font-size:12px; margin-bottom:4px; color:#5f6368;">Or Create New Folder</label>
            <input type="text" id="new-folder" placeholder="e.g. Java Developer" style="width:100%; padding:8px; border:1px solid #dadce0; border-radius:4px;">
        </div>

        <div style="margin-bottom:20px; max-height:150px; overflow-y:auto; border:1px solid #eee; padding:8px;">
            <label style="display:block; font-size:12px; margin-bottom:8px; font-weight:bold;">Select Attachments</label>
            ${attachmentHtml}
        </div>

        <div style="display:flex; justify-content:flex-end; gap:10px;">
            <button id="cancel-btn" style="padding:8px 16px; border:none; background:none; cursor:pointer; color:#5f6368;">Cancel</button>
            <button id="process-btn" style="padding:8px 16px; border:none; background:#0b57d0; color:white; border-radius:4px; cursor:pointer;">Extract & Save</button>
        </div>
        <div id="status-msg" style="margin-top:10px; font-size:13px;"></div>
    `;

    // Bind Events
    document.getElementById('cancel-btn').onclick = () => document.getElementById('gmail-saver-modal').remove();

    document.getElementById('process-btn').onclick = async () => {
        const btn = document.getElementById('process-btn');
        const status = document.getElementById('status-msg');
        btn.disabled = true;
        btn.innerText = 'Processing...';
        status.innerText = '';

        // 1. Get Selections
        const folderSelect = document.getElementById('folder-select');
        const manualInput = document.getElementById('new-folder');
        const finalFolder = manualInput.value.trim() || folderSelect.value;

        // 2. Filter Attachments
        const selectedAttachments = [];
        emailData.attachments.forEach((att, idx) => {
            const cb = document.getElementById(`att-${idx}`);
            if (cb && cb.checked && !att.error) {
                selectedAttachments.push(att);
            }
        });

        if (selectedAttachments.length === 0 && !confirm("No attachments selected. Process email body only?")) {
            btn.disabled = false; btn.innerText = 'Extract & Save';
            return;
        }

        // 3. Send to Background
        const payload = {
            subject: emailData.subject,
            senderEmail: emailData.senderEmail,
            threadLink: emailData.threadLink,
            emailBody: emailData.body,
            attachments: selectedAttachments,
            manualFolderName: finalFolder,
            processedBy: extractLoggedInUser() // [NEW] User Tracking
        };

        chrome.runtime.sendMessage({ action: "processEmail", payload }, (response) => {
            if (response && response.success) {
                status.style.color = 'green';
                status.innerText = 'Started in background! You can move to other emails.';
                // Close modal quickly (1 second) so user can continue working
                setTimeout(() => {
                    const m = document.getElementById('gmail-saver-modal');
                    if (m) m.remove();
                }, 1000);
            } else {
                status.style.color = 'red';
                status.innerText = 'Error: ' + (response ? response.error : 'Unknown error');
                btn.disabled = false;
                btn.innerText = 'Extract & Save';
            }
        });
    };
}

function renderError(modal, msg) {
    modal.innerHTML = `
        <h3 style="color:red">Error</h3>
        <p>${msg}</p>
        <button onclick="document.getElementById('gmail-saver-modal').remove()">Close</button>
    `;
}

// --- 4. EXTRACTION UTILS (From previous brute force version) ---

// --- 4. EXTRACTION UTILS ---

async function expandAllThreads() {
    try {
        const expandIds = ['[aria-label="Expand all"]', 'img[alt="Expand all"]', 'div[data-tooltip="Expand all"]'];
        let expandBtn = null;
        for (const sel of expandIds) {
            expandBtn = document.querySelector(sel);
            if (expandBtn) break;
        }
        if (expandBtn) {
            expandBtn.click();
            await new Promise(r => setTimeout(r, 2000));
        }
    } catch (e) { console.error(e); }
}

async function extractEmailData() {
    try {
        const subjectElement = document.querySelector('h2.hP');
        const subject = subjectElement ? subjectElement.textContent : 'No Subject';
        const messageBodies = document.querySelectorAll('.a3s.aiL');
        let fullBody = '';
        messageBodies.forEach(el => fullBody += el.innerText + '\n---\n');
        if (!fullBody) fullBody = 'No Body Content';

        const rawAttachments = [];
        const seenUrls = new Set();

        // --- SCANNING ---
        // 1. Links
        const allLinks = Array.from(document.querySelectorAll('a'));
        for (const link of allLinks) {
            const url = link.href;
            if (url && (url.includes('view=att') || url.includes('disp=safe') || url.includes('disp=attd'))) {
                await processAttachment(url, link, rawAttachments, seenUrls);
            }
        }

        // 2. Download Elements
        const downloadElements = Array.from(document.querySelectorAll('[aria-label*="Download"], [data-tooltip*="Download"], [download_url]'));
        for (const el of downloadElements) {
            let url = el.getAttribute('href') || el.getAttribute('download_url') || el.dataset.url;
            if (!url) {
                const p = el.closest('a');
                if (p) url = p.href;
            }
            if (url && (url.includes('view=att') || url.includes('disp=safe') || url.includes('disp=attd'))) {
                await processAttachment(url, el, rawAttachments, seenUrls);
            }
        }

        // --- FILTERING & DEDUPLICATION ---
        const uniqueAttachments = [];
        const seenNames = new Set();

        // Allowed Extensions
        const allowedExts = ['.pdf', '.docx', '.doc', '.txt', '.jpg', '.jpeg', '.png'];
        const ignoredNames = ['signature', 'image00', 'logo', 'facebook', 'twitter', 'linkedin'];

        for (const att of rawAttachments) {
            // Clean Name
            let name = att.name;
            // Remove common Gmail UI prefixes
            name = name.replace(/preview attachment/gi, '').replace(/scan/gi, '').trim();
            // Remove leading junk
            name = name.replace(/^[:\-_]+/, '').trim();

            // Re-assign cleaned name
            att.name = name;

            const lowerName = name.toLowerCase();

            // 1. Check Extension
            const hasValidExt = allowedExts.some(ext => lowerName.endsWith(ext));
            if (!hasValidExt) continue; // Skip unknown files

            // 2. Check Blacklist (Signatures/Logos)
            // Often signature images are "image001.png" or "facebook.png"
            const isIgnored = ignoredNames.some(ignored => lowerName.includes(ignored));
            if (isIgnored) continue;

            // 3. Deduplicate by Name
            if (seenNames.has(lowerName)) continue;
            seenNames.add(lowerName);

            uniqueAttachments.push(att);
        }

        return { subject, body: fullBody, attachments: uniqueAttachments };

    } catch (error) {
        console.error('Extraction Error:', error);
        return { subject: 'Error', body: 'Error', attachments: [] };
    }
}

async function processAttachment(url, element, attachments, seenUrls) {
    if (url.startsWith('/')) url = window.location.origin + url;
    if (seenUrls.has(url)) return;
    seenUrls.add(url);

    let filename = element.getAttribute('download');

    // 1. Try ARIA Label / Tooltip (High Confidence)
    if (!filename) {
        const lbl = element.getAttribute('aria-label') || element.getAttribute('data-tooltip') || '';
        if (lbl) {
            const lower = lbl.toLowerCase();
            if (lower.includes('download')) {
                filename = lbl.replace(/download/i, '').replace(/attachment/i, '').trim();
            } else if (lbl.match(/\.[a-zA-Z0-9]{3,4}$/)) {
                filename = lbl;
            }
        }
    }

    // 2. Try Inner Text (Low Confidence - prone to duplication)
    if (!filename) {
        let txt = element.innerText || '';
        txt = txt.trim();
        // Fix "File.pdf File.pdf" issue
        // Split by newline or common separators
        const lines = txt.split(/[\n\r]+/);
        if (lines.length > 0) {
            let candidate = lines[0].trim();
            // Check if it looks like a filename
            if (candidate.match(/\.[a-zA-Z0-9]{3,4}$/)) {
                filename = candidate;
            } else {
                // Formatting might be "File.pdfFile.pdf" (no space)
                // Use regex to find the first occurrence of extensions
                const match = txt.match(/([a-zA-Z0-9_\-\s]+\.(pdf|docx|doc|txt|jpg|png|jpeg))/i);
                if (match) {
                    filename = match[1];
                }
            }
        }
    }

    // 3. Fallback: URL
    if (!filename) {
        // ... existing fallback ...
    }

    // If still no filename, try URL
    if (!filename) {
        try {
            // Gmail URLs sometimes have something?
        } catch (e) { }
    }

    // Temporary Name (will be filtered out if it stays this way)
    if (!filename) filename = `Attachment_${attachments.length}`;

    // Download content via Background Script (to avoid CORS)
    let base64 = null;
    let err = null;
    try {
        const response = await new Promise(resolve => {
            chrome.runtime.sendMessage({ action: "downloadAttachment", url: url }, resolve);
        });

        if (response && response.success) {
            base64 = response.base64;
        } else {
            err = response ? response.error : "Download Failed";
        }
    } catch (e) { err = "Download Failed (Exception)"; }

    attachments.push({ name: filename, mimeType: 'application/octet-stream', contentBase64: base64, error: err });
}

// --- 5. USER EXTRACTION ---
function extractLoggedInUser() {
    try {
        // Attempt 1: Document Title (e.g. "Inbox - user@company.com - Gmail")
        const title = document.title;
        const match = title.match(/-\s+([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\s+-/);
        if (match && match[1]) {
            return match[1];
        }

        // Attempt 2: Google Account Button aria-label
        // Usually contains "Google Account: Name \n(email@gmail.com)"
        const accountBtn = document.querySelector('a[aria-label^="Google Account:"]');
        if (accountBtn) {
            const label = accountBtn.getAttribute('aria-label');
            const emailMatch = label.match(/\(([^)]+)\)/); // Extract text in parentheses
            if (emailMatch && emailMatch[1] && emailMatch[1].includes('@')) {
                return emailMatch[1];
            }
        }

        // Attempt 3: Window Title fallback (sometimes just "Inbox (1) - email@domain.com")
        const simpleMatch = title.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
        if (simpleMatch) {
            return simpleMatch[1];
        }

    } catch (e) {
        console.error("User Extraction Failed:", e);
    }
    return "Unknown User";
}

// Start
init();
